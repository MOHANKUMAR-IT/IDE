<?php
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Run') {
    if (isset($_FILES['uploadedFile']) && $_FILES['uploadedFile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
        $fileName = $_FILES['uploadedFile']['name'];
        $fileType = $_FILES['uploadedFile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $allowedfileExtensions = array('py', 'java', 'js', 'php');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            $uploadFileDir = 'Engine/uploads/';
            $dest_path = $uploadFileDir . $fileName;
            if(move_uploaded_file($fileTmpPath, $dest_path))
            {
                $message ='File is successfully uploaded.';
            }
            else
            {
                $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
            }
            }
            $_SESSION['message'] = $message;
            $f = "Engine\\Dockerfile";
    $arr = array("FROM java","COPY uploads/. /app","WORKDIR /app","CMD bash run_all.sh");
    $lang="";
    $extension = pathinfo($fileName, PATHINFO_EXTENSION);
    if($extension=="py"){$lang="python";}
    elseif($extension=="java")$lang="openjdk";
    elseif($extension=="js")$lang="node";
    $data = "FROM ".$lang;
    $arr[0] = $data;
    file_put_contents($f, implode("\n",$arr));
    // $f = "Engine\\uploads\\run_all.sh";
    // $arr=file("storage.txt");
    // $arr[0] = "for i in *.".$extension;
    // file_put_contents($f, implode("\n",$arr));
    //exec("");
    execInBackground('start cmd.exe @cmd /k "cd Engine && Docker build -t testing . >NUL && docker run --rm -it --name DOCLAB testing && docker rmi testing >NUL"');
    //exec("");
    
    sleep(10);
    unlink($dest_path);
    header("Location: http://localhost/Docker%20App/compileBay.php");
        }
    }
    function execInBackground($cmd) { 
        if (substr(php_uname(), 0, 7) == "Windows"){ 
            pclose(popen("start /B ". $cmd, "r"));  
        } 
        else { 
            exec($cmd . " > /dev/null &");   
        } 
    } 
?>