#!/bin/bash
PY="py"
JV="java"
JS="js"
C="c"
CP="cpp"
PHP="php"
for i in *;do
	filename=$(basename "$i")
	ext="${filename##*.}"
	if [ "$ext" = "$PY" ]; then
	    python3 $i;
	elif [ "$ext" = "$JV" ]; then
	    javac $i && java $(basename "$i");
	elif [ "$ext" = "$JS" ]; then
	    node $i;
	elif [ "$ext" = "$C" ]; then
		gcc $i && ./a.out;
	elif [ "$ext" = "$CP" ]; then
		gcc $i -lstdc++ && ./a.out;
	elif [ "$ext" = "$PHP" ]; then
		php $i;
	fi
done
