<?php
    echo "Hello World :From PHP";
?>