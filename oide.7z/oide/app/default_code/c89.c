#include<stdio.h>

int main(){
    printf("Hello World: From C");
}