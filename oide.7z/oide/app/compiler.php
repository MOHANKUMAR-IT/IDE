<?php
    
    $language = strtolower($_POST['language']);
    $code = $_POST['code'];
    $random = substr(md5(mt_rand()), 0, 7);
    if($language!="python")
    $filePath = "Engine/uploads/" . $random . "." . $language;
    else
    $filePath = "Engine/uploads/" . $random . ".py";
    $programFile = fopen($filePath, "w");
    fwrite($programFile, $code);
    fclose($programFile);
    $f = "Engine\\Dockerfile";
    $arr = array("FROM java","COPY uploads/. /app","WORKDIR /app","CMD bash run_all.sh");
    $lang="";
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    if($language=="python"){$lang="python";}
    elseif($language=="java")$lang="openjdk";
    elseif($language=="node")$lang="node";
    elseif($language=="c")$lang="gcc";
    elseif($language=="cpp")$lang="gcc";
    elseif($language=="php")$lang="php";
    $data = "FROM ".$lang;
    $arr[0] = $data;
    file_put_contents($f, implode("\n",$arr));
    execInBackground('start cmd.exe @cmd /k "cd Engine && Docker build -t testing . >NUL && docker run --rm -it --name DOCLAB testing && docker rmi testing >NUL"');    
    sleep(10);
    unlink($filePath);
    function execInBackground($cmd) { 
      if (substr(php_uname(), 0, 7) == "Windows"){ 
          pclose(popen("start /B ". $cmd, "r"));  
      } 
      else { 
          exec($cmd . " > /dev/null &");   
      }
    }
?>
